import "dotenv/config";
import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import pkg from "pg";

const { Client } = pkg;

// --- Config ---
const PORT = process.env.PORT || 3000;
const DATABASE_URL = process.env.DATABASE_URL;
const CORS_ORIGIN = process.env.CORS_ORIGIN || "*";

// --- DB client ---
const db = new Client({
  connectionString: DATABASE_URL
});

async function initDb() {
  await db.connect();
  console.log("Connected to PostgreSQL");

  // Ensure schema exists (same as earlier, but safe to run)
  await db.query(`
    CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      username TEXT UNIQUE NOT NULL,
      created_at TIMESTAMP DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS rooms (
      id SERIAL PRIMARY KEY,
      name TEXT UNIQUE NOT NULL,
      created_at TIMESTAMP DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS messages (
      id SERIAL PRIMARY KEY,
      room_id INTEGER NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
      user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
      username TEXT NOT NULL,
      content TEXT NOT NULL,
      created_at TIMESTAMP DEFAULT NOW()
    );

    INSERT INTO rooms (name)
    VALUES ('global')
    ON CONFLICT (name) DO NOTHING;
  `);

  console.log("Schema ensured");
}

// --- Express + HTTP + Socket.IO ---
const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: CORS_ORIGIN,
    methods: ["GET", "POST"]
  }
});

// Simple health check
app.get("/", (req, res) => {
  res.send("Chat server is running");
});

// Helper: get room id by name (creates if missing)
async function getOrCreateRoomId(roomName) {
  const result = await db.query(
    `INSERT INTO rooms (name)
     VALUES ($1)
     ON CONFLICT (name) DO UPDATE SET name = EXCLUDED.name
     RETURNING id`,
    [roomName]
  );
  return result.rows[0].id;
}

// Helper: create or get user
async function getOrCreateUserId(username) {
  const result = await db.query(
    `INSERT INTO users (username)
     VALUES ($1)
     ON CONFLICT (username) DO UPDATE SET username = EXCLUDED.username
     RETURNING id`,
    [username]
  );
  return result.rows[0].id;
}

// --- Socket.IO logic ---
io.on("connection", socket => {
  console.log("Client connected:", socket.id);

  // Join a room
  socket.on("join_room", async ({ roomName = "global", username = "Guest" }) => {
    try {
      const roomId = await getOrCreateRoomId(roomName);
      const userId = await getOrCreateUserId(username);

      socket.join(roomName);
      console.log(`${username} joined room ${roomName}`);

      // Load last 50 messages
      const history = await db.query(
        `SELECT username, content, created_at
         FROM messages
         WHERE room_id = $1
         ORDER BY created_at DESC
         LIMIT 50`,
        [roomId]
      );

      // Send history only to this client
      socket.emit("chat_history", {
        roomName,
        messages: history.rows.reverse()
      });

      // Notify others
      socket.to(roomName).emit("system_message", {
        roomName,
        message: `${username} joined the room`
      });

      // Store on socket for later
      socket.data.username = username;
      socket.data.roomName = roomName;
      socket.data.userId = userId;
      socket.data.roomId = roomId;
    } catch (err) {
      console.error("join_room error:", err);
      socket.emit("error_message", { message: "Failed to join room" });
    }
  });

  // Receive chat message
  socket.on("chat_message", async ({ content }) => {
    const username = socket.data.username || "Guest";
    const roomName = socket.data.roomName || "global";
    const roomId = socket.data.roomId;

    if (!content || !roomId) return;

    try {
      const result = await db.query(
        `INSERT INTO messages (room_id, user_id, username, content)
         VALUES ($1, $2, $3, $4)
         RETURNING id, created_at`,
        [roomId, socket.data.userId || null, username, content]
      );

      const message = {
        id: result.rows[0].id,
        roomName,
        username,
        content,
        created_at: result.rows[0].created_at
      };

      // Broadcast to everyone in the room
      io.to(roomName).emit("chat_message", message);
    } catch (err) {
      console.error("chat_message error:", err);
      socket.emit("error_message", { message: "Failed to send message" });
    }
  });

  socket.on("disconnect", () => {
    console.log("Client disconnected:", socket.id);
  });
});

app.post("/updatePlayer", async (req, res) => {
  const { id, username, skin_index, x, y } = req.body;

  await pool.query(`
    INSERT INTO players_online (id, username, skin_index, x, y, last_update)
    VALUES ($1, $2, $3, $4, $5, NOW())
    ON CONFLICT (id)
    DO UPDATE SET
      username = EXCLUDED.username,
      skin_index = EXCLUDED.skin_index,
      x = EXCLUDED.x,
      y = EXCLUDED.y,
      last_update = NOW();
  `, [id, username, skin_index, x, y]);

  res.json({ ok: true });
});

app.get("/getPlayers", async (req, res) => {
  const result = await pool.query(`
    SELECT * FROM players_online
    WHERE last_update > NOW() - INTERVAL '5 seconds'
  `);

  res.json(result.rows);
});

// --- Start server ---
(async () => {
  try {
    await initDb();
    httpServer.listen(PORT, () => {
      console.log(`Chat server listening on port ${PORT}`);
    });
  } catch (err) {
    console.error("Failed to start server:", err);
    process.exit(1);
  }
})();
